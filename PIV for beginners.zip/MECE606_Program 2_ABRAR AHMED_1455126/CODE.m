function varargout = ABRAR_MECE606(varargin)
% ABRAR_MECE606 MATLAB code for ABRAR_MECE606.fig
%      ABRAR_MECE606, by itself, creates a new ABRAR_MECE606 or raises the existing
%      singleton*.
%
%      H = ABRAR_MECE606 returns the handle to a new ABRAR_MECE606 or the handle to
%      the existing singleton*.
%
%      ABRAR_MECE606('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ABRAR_MECE606.M with the given input arguments.
%
%      ABRAR_MECE606('Property','Value',...) creates a new ABRAR_MECE606 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ABRAR_MECE606_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ABRAR_MECE606_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ABRAR_MECE606

% Last Modified by GUIDE v2.5 23-Oct-2018 10:16:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ABRAR_MECE606_OpeningFcn, ...
                   'gui_OutputFcn',  @ABRAR_MECE606_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ABRAR_MECE606 is made visible.
function ABRAR_MECE606_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ABRAR_MECE606 (see VARARGIN)

% Choose default command line output for ABRAR_MECE606
handles.output = hObject;
global a %global variable declaration for scaling
a=1;     %initial value of the scaling factor
global b %global variable declaration for offset
b=0;     %initial value for same offseting at both axis
% Update handles structure
guidata(hObject, handles);



% UIWAIT makes ABRAR_MECE606 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ABRAR_MECE606_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
% --- Executes on button press in Load1.
function Load1_Callback(hObject, eventdata, handles)
% hObject    handle to Load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%If we want to use a variable in GUI several times then it is recommended
%to use global variable as written in the folng code:

global info1
global filename1
global pathname1
[filename1, pathname1]=uigetfile({'*.*';'*.jpg';'*.png';'*.bmp';'*.tif'});
info1=imfinfo(filename1);  
axes(handles.axes1);
handles.a=imread(filename1); %imread Read image from graphics file. For more info please read matlab help file. Just write help in matlab command window
 

global W0            %global variable for initial width of the image
global H0            %global variable for initial height of the image
% [pathname1,filename1]=uigetfile({'*.*';'*.jpg';'*.png';'*.bmp';'*.tif'});
W0=0:info1.Width;
H0=0:info1.Height;

%Itr is to be noted that the initial values will be equal to the original 
%scale of the images
global W          %width of the image before/after scaling
global H          %Height of the image before/after scaling
W=W0;
H=H0;

%The following code will generate global variables to store the offset 
%value of the scale of the images
% along the x and y coordinates, called offsetx and offsety. 
%We can provide offset value in the edit text box for offset value,
%but the initial value is set at 0
global offsetx
global offsety
offsetx=0;
offsety=0;
%Create global variable to store the scaling factor . The initial value is 1
global scale
scale=1;
%Show figure in the axis panel and display the information of the image in
%the allocated static/edit text box. Also, display the values of the
%offsets and scaling factor in the corresponding panels
 %imread Read image from graphics file. For more info please read matlab help file. Just write help in matlab command window
imagesc(W,H,handles.a);  % imagesc Display image with scaled colors.  For more info please read matlab help file. Just write help in matlab command window  
colormap (gray);  % imagesc shows any images in blue color. In order to see them clearly we can use colormap.  


handles.ref=1;  % declaring a variable "ref" for toggling images
% %__________________________________________
% %%% Showing Image properties
% %__________________________________________
% % Extracting the image info
 info1=imfinfo(filename1);  
 set(handles.Pathname1,'string',filename1); %% this will show us the image location 
 set(handles.width,'string',num2str(info1.Width));
 set(handles.height,'string',num2str(info1.Height));
 set(handles.Ext,'string',num2str(info1.Format));
 set(handles.size,'string',num2str(info1.BitDepth));
% %Updating handles
guidata(hObject, handles);

% --- Executes on button press in load2.
function load2_Callback(hObject, eventdata, handles)
% hObject    handle to load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global info2
global filename2
global pathname2

[filename2, pathname2]=uigetfile({'*.*';'*.jpg';'*.png';'*.bmp';'*.tif'});
info2=imfinfo(filename2); 
global W0
global H0
W0=0:info2.Width;
H0=0:info2.Height;
%Create global variables (W for width and H for height height) to store 
%the modified scale of the images
%The initial values will be equal to the original scale of the images
global W
global H
W=W0;
H=H0;

%Create global variables to store the offset of the scale of the images
% in the x and y directions, called offsetx and offsety. User will modify
% the variable, but the initial value is 0
global offsetx
global offsety
offsetx=0;
offsety=0;


%Create global variable to store the scaling factor specified by the user. The
%initial value is 1
global scale
scale=1;

%Show figure in figure panel and display the information of the image in
%the image information pane. Also, display the initial values of the
%offsets and scaling factor in the corresponding panels
axes(handles.axes1);
handles.b=imread(filename2);
imagesc(W,H,handles.b);
colormap (gray);   
handles.ref=2; % variable for toggling

% %__________________________________________
% %%% Showing Image properties
% %__________________________________________
 
info2=imfinfo(filename2); 
set(handles.Pathname1,'string',filename2); %% this will show us the image location 
set(handles.width,'string',num2str(info2.Width));
set(handles.height,'string',num2str(info2.Height));
set(handles.Ext,'string',num2str(info2.Format));
 set(handles.size,'string',num2str(info2.BitDepth));

%Updating handles
guidata(hObject, handles)


% --- Executes on button press in toggle.
function toggle_Callback(hObject, eventdata, handles)
global filename1
global filename2
global info1
global info2
global W
global H
% hObject    handle to toggle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.ref==1
    axes(handles.axes1);
    imagesc(W,H,handles.b); % if 'ref' variable is set with image 1, this will show image 2
    colormap(gray)
    handles.ref=2;
    
%display image info
set(handles.Pathname1,'string',filename2); %% this will show us the image location 
 set(handles.width,'string',num2str(info2.Width));
 set(handles.height,'string',num2str(info2.Height));
 set(handles.Ext,'string',num2str(info2.Format));
 set(handles.size,'string',num2str(info2.BitDepth));
 
elseif handles.ref==2 % if 'ref' variable is set with image 2, this will show image 1
     axes(handles.axes1);
    imagesc(W,H,handles.a)   
    colormap(gray)
    handles.ref=1;
 %display image info
 set(handles.Pathname1,'string',filename1); %% this will show us the image location 
 set(handles.width,'string',num2str(info1.Width));
 set(handles.height,'string',num2str(info1.Height));
 set(handles.Ext,'string',num2str(info1.Format));
 set(handles.size,'string',num2str(info1.BitDepth));
end
%Updating handles
guidata(hObject, handles)

% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

             %%%%%______________________________%%%%%%%%%%%
              %%%%%%%Settings for Scaling Factors%%%%%%%%%%%%
              %%%%%______________________________%%%%%%%%%%%

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

function scale_Callback(hObject, eventdata, handles)
% hObject    handle to scale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of scale as text
%        str2double(get(hObject,'String')) returns contents of scale as a double
global H0;
global W0;
global H;
global W;
global offsetx;
global offsety;
global scale;

scale = str2num(get(handles.scale,'string'));%get the input for scaling factor 
W=offsetx+(scale.*W0);                   % Formula to calculate the change of the scale based in the inputs of scale and X offset
H=offsety+(scale.*H0);                 % Formula to calculate the change of the scale based in the inputs of scale and Y offset

if handles.ref==2  
axes(handles.axes1);
imagesc(W,H,handles.b);
colormap (gray);   

elseif handles.ref==1
    axes(handles.axes1);
imagesc(W,H,handles.a);
colormap (gray);

end



% --- Executes during object creation, after setting all properties.
function scale_CreateFcn(hObject, eventdata, handles)
% hObject    handle to scale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

              %%%%%______________________________%%%%%%%%%%%
              %%%%%%%Settings for OFFSETS%%%%%%%%%%%%
              %%%%%______________________________%%%%%%%%%%%

function offsetx_Callback(hObject, eventdata, handles)
% hObject    handle to offsetx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of offsetx as text
%        str2double(get(hObject,'String')) returns contents of offsetx as a double

global info1
global info2
global H0;
global W0;
global H;
global W;
global offsetx;
global offsety;
global scale;


offsetx = str2num(get(handles.offsetx,'string'));%get the input of X offset from the user
W=offsetx+(scale.*W0);

if handles.ref==2
    axes(handles.axes1);
imagesc(W,H,handles.b);
colormap (gray);             

elseif handles.ref==1
    axes(handles.axes1);
imagesc(W,H,handles.a);
colormap (gray);
end


function offsetx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to offsetx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function offsety_Callback(hObject, eventdata, handles)
% hObject    handle to offsety (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of offsety as text
%        str2double(get(hObject,'String')) returns contents of offsety as a double

global H0;
global W0;
global H;
global W;
global offsety;
global scale;


offsety = str2num(get(handles.offsety,'string'));%get the input scaling factor from the end user
H=offsety+(scale.*H0); 
if handles.ref==2
    axes(handles.axes1);
imagesc(W,H,handles.b);
colormap (gray);             

elseif handles.ref==1
    axes(handles.axes1);
imagesc(W,H,handles.a);
colormap (gray);
end

% --- Executes during object creation, after setting all properties.
function offsety_CreateFcn(hObject, eventdata, handles)
% hObject    handle to offsety (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function width_Callback(hObject, eventdata, handles)
% hObject    handle to width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of width as text
%        str2double(get(hObject,'String')) returns contents of width as a double


% --- Executes during object creation, after setting all properties.
function width_CreateFcn(hObject, eventdata, handles)
% hObject    handle to width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function height_Callback(hObject, eventdata, handles)
% hObject    handle to height (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of height as text
%        str2double(get(hObject,'String')) returns contents of height as a double


% --- Executes during object creation, after setting all properties.
function height_CreateFcn(hObject, eventdata, handles)
% hObject    handle to height (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

                       %%% Instructions%%%%%
% --- Executes on button press in Instructions.
function Instructions_Callback(hObject, eventdata, handles)
% hObject    handle to Instructions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox({'Instructions:' ;
    'Click on Load Image-1 & Load Image-2 to browse and select two images';
    'Press Toggle button to switch the images';
    'Input scaling factor and offset value to map the images from a pixel space to physical space';
    'The app may not work if .m file is not opened before .fig file';
    'for further queries please contact at: abrar5@ualberta.ca'}, 'Instructions')
                       



                      % ____________________________%
                       %%%%%%%%% PROGRAM 2%%%%%%%%%
                       %___________________________%
                            %%%% Overlap%%%%%%

function overlap_Callback(hObject, eventdata, handles)
% hObject    handle to overlap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of overlap as text
%        str2double(get(hObject,'String')) returns contents of overlap as a double


% --- Executes during object creation, after setting all properties.
function overlap_CreateFcn(hObject, eventdata, handles)
% hObject    handle to overlap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function location_x_Callback(hObject, eventdata, handles)
% hObject    handle to location_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of location_x as text
%        str2double(get(hObject,'String')) returns contents of location_x as a double


% --- Executes during object creation, after setting all properties.
function location_x_CreateFcn(hObject, eventdata, handles)
% hObject    handle to location_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function location_y_Callback(hObject, eventdata, handles)
% hObject    handle to location_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of location_y as text
%        str2double(get(hObject,'String')) returns contents of location_y as a double


% --- Executes during object creation, after setting all properties.
function location_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to location_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in calculate.
function calculate_Callback(hObject, eventdata, handles)
% hObject    handle to calculate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global filename1
global filename2
global X
global Y
global gap_length

img_1 = imread(filename1);
img_2 = imread(filename2);

X = str2double(get(handles.location_x, 'String'));
Y = str2double(get(handles.location_y, 'String'));

size_window = str2double(get(handles.windowsize, 'String')); % get window size
overlap = str2double(get(handles.overlap, 'String'));   % get overlap value

info2=imfinfo(filename2);
handles.info2=[cellstr(info2.Format)';num2cell(info2.Width);num2cell(info2.Height); num2cell(info2.BitDepth);info2.Filename];



% Calculation regarding shifting of window due to overlapping
gap_length = floor(size_window - (size_window*overlap/100));

x_count = floor(X/gap_length);
x_begin = x_count*gap_length;
y_count = floor(Y/gap_length);
y_begin = y_count*gap_length;


for i=1:size_window
    for j=1:size_window
        A(i,j) = img_1(y_begin+j, x_begin+i);
    end
end

for m=1:size_window
    for n=1:size_window
        B(m,n) = img_2(y_begin+n, x_begin+m);
    end
end

%using normxcorr2 function to calculate the normalized cross correlation
rectangle('Position',[X Y size_window size_window], 'LineWidth',1, 'EdgeColor', 'green');

c = normxcorr2(double(A),double(B));
axes(handles.result_axis)
% figure
surf(c)
colorbar

shading flat

% --- SINGLE CLICK OPTION FOR CROSS CORElATION
function singleclick_Callback(hObject, eventdata, handles)
% hObject    handle to singleclick (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global filename1
global filename2 
global R1      % variable for the square to surround the location
global size_window
global img_1
global img_2
global gap_length
img_1 = imread(filename1);
img_2 = imread(filename2);


[x_pos,y_pos] = ginput(1);       %ginput(1)considers Graphical input from mouse or cursor

info2=imfinfo(filename2);
handles.info2=[cellstr(info2.Format)';num2cell(info2.Width);num2cell(info2.Height); num2cell(info2.BitDepth);info2.Filename];

% Here we want to include an error message with explanation as user may be
% confused if they click on a region which is not complemented with window
% size and X,Y coordinate
if handles.info2{2}< (x_pos+size_window)
    msgbox('Selected window location goes beyond the image. Try again','Error','Error')
    return
end

if handles.info2{3}< (y_pos+size_window)
    msgbox('Selected window location goes beyond the image. Try again','Error','Error')
    return
end

size_window = str2double(get(handles.windowsize, 'String'));
overlap = str2double(get(handles.overlap, 'String'));
gap_length = floor(size_window - (size_window*overlap/100));
x_count = floor(x_pos/gap_length);
x_begin = x_count*gap_length;
y_count = floor(y_pos/gap_length);
y_begin = y_count*gap_length;


for i=1:size_window
       for j=1:size_window
        A(i,j) = img_1(y_begin+j, x_begin+i);
    end
end

for m=1:size_window
    for n=1:size_window
        B(m,n) = img_2(y_begin+n, x_begin+m);
    end
end

R1 = rectangle('Position',[x_pos y_pos size_window size_window],'LineWidth',1.5,'Edgecolor', 'green');
c = normxcorr2(double(A),double(B));
axes(handles.result_axis);
% figure
surf(c)
colorbar
shading flat



function pause_Callback(hObject, eventdata, handles)
% hObject    handle to pause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pause as text
%        str2double(get(hObject,'String')) returns contents of pause as a double


% --- Executes during object creation, after setting all properties.
function pause_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in scan.
function scan_Callback(hObject, eventdata, handles)
% hObject    handle to scan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global filename1
global filename2
global gap_length


img_1 = imread(filename1);
img_2 = imread(filename2);

size_window = str2double(get(handles.windowsize, 'String'));
overlap = str2double(get(handles.overlap, 'String'));

gap_length = floor(size_window - (size_window*overlap/100));
info = imfinfo(filename2);
width = (info.Width);
height = (info.Height);

% Calculating number of windows in the X and Y directions
x_window = size_window/2;
y_window = size_window/2;



for m = x_window+1:(size_window+1):width+x_window
       for n = y_window+1:(size_window+1):height+y_window
           if (m+x_window) < width
               if (n+y_window) < height
               A = img_1(n-y_window:n+y_window, m-x_window:m+x_window);
               B = img_2(n-y_window:n+y_window, m-x_window:m+x_window);
               else
               A = img_1(n-y_window:end, m-x_window:m+x_window);
               B = img_2(n-y_window:end, m-x_window:m+x_window);
               end
           else
               if (n+y_window) < height
               A = img_1(n-y_window:n+y_window, m-x_window:end);
               B = img_2(n-y_window:n+y_window, m-x_window:end);
               
               else
               A = img_1(n-y_window:end, m-x_window:end);
               B = img_2(n-y_window:end, m-x_window:end);    
               end
           end
           c = normxcorr2(double(A),double(B));
           axes(handles.result_axis);
           %figure
           surf(c)
           colorbar
           shading flat
           axes(handles.axes1);
           rectangle('Position',[ (m/x_window)*gap_length (n/y_window)*gap_length size_window size_window],'LineWidth',1.5,'Edgecolor', 'green');
           
          p = str2double(get(handles.pause, 'String'));
           
           pause (1/p)
           
       end
end


function windowsize_Callback(hObject, eventdata, handles)
% hObject    handle to windowsize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of windowsize as text
%        str2double(get(hObject,'String')) returns contents of windowsize as a double


% --- Executes during object creation, after setting all properties.
function windowsize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to windowsize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Instructions_CC.
function Instructions_CC_Callback(hObject, eventdata, handles)
% hObject    handle to Instructions_CC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox({'Instructions:' ;
    'In the window size box give input for your desired window size and it will be a square box';
    'Write the percentage of the window overlap in the overlap box,e.g., here 50 means 50% overlap';
    'pressing calculate will locate the sub-region where the cross correlation is being calculated ';
    'N.B: Please be careful if you dont input for the location of X and Y axis, overlap and window size then calculate will show error';
    'pressing Single Click will locate and determine the cross correlation with the place in the image where mouse is clicked';
    'Scan and sweep speed will automatically scan over the whole image with the desired window size and overlap input';
    'N.B: more value in the seep speed control box means higher speed and vice-versa'
    'for further queries please contact at: abrar5@ualberta.ca'}, 'Instructions')


% --- Executes on button press in info_speed.
function info_speed_Callback(hObject, eventdata, handles)
% hObject    handle to info_speed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox({'Instructions:' ;
    
    'N.B: more value in the sweep speed control box means higher speed and vice-versa'
    }, 'info_speed')
